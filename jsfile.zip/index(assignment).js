// // // access child node
//  let parent=document.getElementById("parent");
//  console.log(parent.childnodes);
// let child = document.getElementById("child");

// // Simple way to access parent
// let parent = child.parentElement;

// console.log(parent);
// create new element

// let newElement = document.createElement("p");


// newElement.innerText = "Hello, I am new here!";


// document.getElementById("container").appendChild(newElement);
// add and delete elements to  THE DOM
// HOW TO add elements in dom

// let newOne = document.createElement("p");
// newOne.innerText = "hi am here ...";


//  document.getElementById("sum").appendChild(newOne);
// // how to delete elements
// let element = document.getElementById("remove");
// element.remove();
// how to access add , remove attributes
// acces attribute

// let link = document.getElementById("Link");

// console.log(link.href);  
// how to add attributes
// let link = document.getElementById("myLink");

// link.setAttribute("href", "https://google.com");


// link.setAttribute("href", "https://google.com");
// how to add attributes
// let link = document.getElementById("myLink");

// link.removeAttribute("href");
// how to add elements
// let container = document.getElementById("container");

// // Create element
// let p = document.createElement("p");

// p.textContent = "This is a new paragraph.";


// container.appendChild(p);





 

